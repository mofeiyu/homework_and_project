import tensorflow as tf
a = tf.constant(1)
print a